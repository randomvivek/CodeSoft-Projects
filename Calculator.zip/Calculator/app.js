let display = document.getElementById("display");
let currentInput = "";
let operator = "";
let previousInput = "";
let shouldResetDisplay = false;

function playSound(soundId) {
  const sound = document.getElementById(soundId);
  sound.currentTime = 0; // Reset sound to start
  sound.play();
}

function appendToDisplay(value) {
  playSound("click-sound"); // Play click sound
  if (shouldResetDisplay) {
    currentInput = "";
    shouldResetDisplay = false;
  }

  // Handle operators
  if (["+", "-", "*", "/"].includes(value)) {
    if (currentInput === "" && previousInput === "") {
      return; // Don't allow operator as first input
    }

    if (currentInput !== "") {
      if (previousInput !== "" && operator !== "") {
        calculate();
      } else {
        previousInput = currentInput;
      }
    }

    operator = value;
    currentInput = "";
    updateDisplay();
    return;
  }

  // Handle decimal point
  if (value === ".") {
    if (currentInput.includes(".")) {
      return; // Don't allow multiple decimal points
    }
    if (currentInput === "") {
      currentInput = "0";
    }
  }

  currentInput += value;
  updateDisplay();
}

function updateDisplay() {
  if (currentInput !== "") {
    display.value = currentInput;
  } else if (previousInput !== "") {
    display.value = previousInput + " " + getOperatorSymbol(operator);
  }
}

function getOperatorSymbol(op) {
  switch (op) {
    case "+":
      return "+";
    case "-":
      return "−";
    case "*":
      return "×";
    case "/":
      return "÷";
    default:
      return "";
  }
}

function calculate() {
  if (previousInput === "" || currentInput === "" || operator === "") {
    return;
  }

  let result;
  let prev = parseFloat(previousInput);
  let current = parseFloat(currentInput);

  // Perform calculation based on operator
  switch (operator) {
    case "+":
      result = prev + current;
      break;
    case "-":
      result = prev - current;
      break;
    case "*":
      result = prev * current;
      break;
    case "/":
      if (current === 0) {
        playSound("error-sound"); // Play error sound
        display.value = "Error";
        resetCalculator();
        return;
      }
      result = prev / current;
      break;
    default:
      return;
  }

  // Handle decimal precision
  if (result % 1 !== 0) {
    result = parseFloat(result.toFixed(8));
  }

  display.value = result;
  previousInput = result.toString();
  currentInput = "";
  operator = "";
  shouldResetDisplay = true;
}

function clearDisplay() {
  playSound("click-sound"); // Play click sound
  resetCalculator();
  display.value = "";
}

function deleteLast() {
  playSound("click-sound"); // Play click sound
  if (currentInput !== "") {
    currentInput = currentInput.slice(0, -1);
    updateDisplay();
    if (currentInput === "") {
      display.value = "";
    }
  }
}

function resetCalculator() {
  currentInput = "";
  previousInput = "";
  operator = "";
  shouldResetDisplay = false;
}

// Keyboard support
document.addEventListener("keydown", function (event) {
  const key = event.key;

  if ((key >= "0" && key <= "9") || key === ".") {
    appendToDisplay(key);
  } else if (["+", "-", "*", "/"].includes(key)) {
    appendToDisplay(key);
  } else if (key === "Enter" || key === "=") {
    event.preventDefault();
    calculate();
  } else if (key === "Escape" || key === "c" || key === "C") {
    clearDisplay();
  } else if (key === "Backspace") {
    deleteLast();
  }
});

// Initialize display
display.value = "";
